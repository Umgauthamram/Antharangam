# Standalone GitHub Scraper

This is a simple, standalone Node.js tool to scrape GitHub repositories using Puppeteer.

## 1. Prerequisites
- **Node.js installed**: [Download here](https://nodejs.org/)

## 2. Installation
Open a terminal in this folder and run:
```bash
npm install
```
This will install `puppeteer` and `puppeteer-extra`.

## 3. How to Run
Run the script with your keyword:

```bash
node github_scraper.js "leaked credentials"
```

Or just run it directly (defaults to "leaked credentials"):
```bash
node github_scraper.js
```

## 4. Output
- The script will open a Chromium browser (visible mode) so you can see it working.
- It will extract repository names, descriptions, and authors.
- Results will be saved to `github_results.json` in this folder.

## File Structure
- `github_scraper.js`: The main code.
- `package.json`: Dependency list.
- `github_results.json`: Output file (created after running).
