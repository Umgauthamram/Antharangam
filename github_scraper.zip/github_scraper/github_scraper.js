const puppeteer = require('puppeteer-extra');
const StealthPlugin = require('puppeteer-extra-plugin-stealth');
const fs = require('fs');

puppeteer.use(StealthPlugin());

const KEYWORD = process.argv[2] || "leaked credentials";

async function scrapeGitHub(query) {
    console.log(`Starting GitHub Scraper for: "${query}"`);


    // 'headless: false' means you will actually SEE the browser open.
    const browser = await puppeteer.launch({
        headless: false,
        args: [
            '--no-sandbox',
            '--disable-setuid-sandbox',
            '--disable-blink-features=AutomationControlled'
        ]
    });

    const page = await browser.newPage();

    await page.setUserAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36");

    await page.setViewport({ width: 1280, height: 800 });

    try {
        const url = `https://github.com/search?q=${encodeURIComponent(query)}&type=repositories`;
        console.log(`Navigating to: ${url}`);

        await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 60000 });

        const selector = 'div[data-testid="results-list"] > div';
        try {
            await page.waitForSelector(selector, { timeout: 15000 });
        } catch (e) {
            console.log("Timeout waiting for results. You might need to login manually or the selector changed.");
        }

        const results = await page.$$eval(selector, (elements) => {
            return elements.map(el => {
                const titleEl = el.querySelector('h3 a, span a');
                const descEl = el.querySelector('span[class*="Text"], div[class*="Text"]');
                const dateEl = el.querySelector('relative-time');

                const href = titleEl ? titleEl.href : null;
                const repoText = titleEl ? titleEl.innerText : 'Unknown';
                const description = descEl ? descEl.innerText : '';
                const timestamp = dateEl ? dateEl.getAttribute('datetime') : new Date().toISOString();

                const author = repoText.split('/')[0] || 'GitHub User';

                return {
                    platform: 'github',
                    author: author.trim(),
                    content: `Repository: ${repoText}\nDescription: ${description}`,
                    url: href,
                    timestamp: timestamp
                };
            });
        });

        console.log(`Found ${results.length} repositories.`);

        if (results.length > 0) {
            fs.writeFileSync('github_results.json', JSON.stringify(results, null, 2));
            console.log(`Saved results to github_results.json`);
            console.log(`Check the file 'github_results.json' to see your data!`);
        } else {
            console.log("No results found.");
        }

    } catch (error) {
        console.error("Error:", error.message);
    } finally {
        console.log("browser Closing  in 5 seconds");
        await new Promise(r => setTimeout(r, 5000));
        await browser.close();
    }
}

scrapeGitHub(KEYWORD);
